from setuptools import setup

setup(
	name="dthings-py",
	version="1.0.0",
	description="Get information users and bots from discordthings.com",
	author="Surui#5566",
	packages=["functions"]
	)